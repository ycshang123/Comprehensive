package com.soft1851.admin.mapper;

import com.soft1851.my.mapper.MyMapper;
import com.soft1851.pojo.AdminUser;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminUserMapper extends MyMapper<AdminUser> {
}