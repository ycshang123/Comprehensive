package com.soft1851.user.mapper;

import com.soft1851.my.mapper.MyMapper;
import com.soft1851.pojo.Fans;

public interface FansMapper extends MyMapper<Fans> {
}